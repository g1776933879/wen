package com.qingxuan.wenpush;

import android.content.*;
import android.net.Uri;
import android.webkit.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** WebView JS 桥 —— 青玄 */
public class Bridge {

    public interface Emit { void send(String json); }

    private final Context ctx;
    private final Emit emit;
    private final GithubApi api = new GithubApi();
    private Engine engine;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Map<String, JSONObject> tasks = new LinkedHashMap<String, JSONObject>();
    private final List<String> order = new ArrayList<String>();
    private SharedPreferences sp;

    public Bridge(Context c, Emit e) {
        ctx = c;
        emit = e;
        sp = c.getSharedPreferences("wenpush", Context.MODE_PRIVATE);
        api.token = sp.getString("token", "").trim();
        api.owner = sp.getString("owner", "");
        engine = new Engine(api, new File(c.getCacheDir(), "tmp"));
    }

    void fire(String type, Object payload) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("payload", payload);
            emit.send(o.toString());
        } catch (Exception e) {}
    }

    public String state() {
        try {
            JSONObject o = new JSONObject();
            o.put("owner", api.owner);
            o.put("token_hint", api.token.length() > 12 ? api.token.substring(0, 7) + "..." + api.token.substring(api.token.length() - 4) : "");
            o.put("has_token", api.token.length() > 0);
            o.put("default_repo", sp.getString("repo", ""));
            o.put("branch", sp.getString("branch", "main"));
            JSONArray arr = new JSONArray();
            synchronized (tasks) {
                List<String> rev = new ArrayList<String>(order);
                Collections.reverse(rev);
                for (String id : rev) arr.put(tasks.get(id));
            }
            o.put("tasks", arr);
            o.put("git_max", Engine.GIT_MAX);
            o.put("git_huge", Engine.GIT_HUGE);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    public void saveConfig(String token, String owner, String repo, String branch) {
        SharedPreferences.Editor ed = sp.edit();
        if (token != null && token.length() > 0) { api.token = token.trim(); ed.putString("token", api.token); }
        if (owner != null && owner.length() > 0) { api.owner = owner.trim(); ed.putString("owner", api.owner); }
        if (repo != null && repo.length() > 0) ed.putString("repo", repo.trim());
        if (branch != null && branch.length() > 0) ed.putString("branch", branch.trim());
        ed.apply();
        fire("toast", "配置已保存");
        fire("state", state());
    }
    public void push(final String pathsJson, final String repo, final String branch,
                     final String rel, final String mode) {
        try {
            JSONArray arr = new JSONArray(pathsJson);
            for (int i = 0; i < arr.length(); i++) {
                String path = arr.getString(i).trim();
                if (path.isEmpty()) continue;
                final File f = new File(path);
                if (!f.exists()) { fire("toast", "路径不存在: " + path); continue; }
                final String id = "t" + System.currentTimeMillis() + (int) (Math.random() * 999);
                JSONObject t = new JSONObject();
                t.put("id", id);
                t.put("name", f.getName());
                t.put("size", f.isFile() ? f.length() : dirSize(f));
                t.put("done", 0);
                t.put("status", "pending");
                t.put("msg", "排队中");
                t.put("channel", Engine.channel(t.getLong("size"), mode));
                synchronized (tasks) { tasks.put(id, t); order.add(id); }
                fire("state", state());
                pool.submit(new Runnable() { public void run() {
                    runTask(id, f, repo, branch, rel, mode);
                }});
            }
        } catch (Exception e) {
            fire("toast", "提交失败: " + e.getMessage());
        }
    }

    static long dirSize(File d) {
        long n = 0;
        File[] fs = d.listFiles();
        if (fs == null) return 0;
        for (File f : fs) n += f.isDirectory() ? dirSize(f) : f.length();
        return n;
    }

    void upd(String id, String key, Object val) {
        synchronized (tasks) {
            JSONObject t = tasks.get(id);
            if (t == null) return;
            try { t.put(key, val); } catch (Exception e) {}
        }
    }

    void runTask(String id, File src, String repo, String branch, String rel, String mode) {
        try {
            if (repo == null || repo.isEmpty()) repo = sp.getString("repo", "");
            if (branch == null || branch.isEmpty()) branch = sp.getString("branch", "main");
            if (api.token.isEmpty()) throw new IOException("未配置 Token");
            if (repo == null || repo.isEmpty()) throw new IOException("未指定仓库");

            long size = src.isFile() ? src.length() : dirSize(src);
            String ch = Engine.channel(size, mode);
            upd(id, "status", "running");
            upd(id, "channel", ch);
            upd(id, "msg", "开始处理");
            fire("state", state());

            final String tid = id;
            final long t0 = System.currentTimeMillis();
            GithubApi.Progress prog = new GithubApi.Progress() {
                public void on(long done, long total) {
                    upd(tid, "done", done);
                    long el = System.currentTimeMillis() - t0;
                    if (el > 300) upd(tid, "speed", done * 1000.0 / el);
                    fire("state", state());
                }
            };

            if ("release".equals(ch)) {
                String tag = sp.getString("tagprefix", "push") + "-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
                upd(id, "msg", "分卷检查");
                fire("state", state());
                List<File> parts = engine.split(src);
                JSONObject relObj = engine.getOrCreateRelease(repo, tag);
                for (File p : parts) {
                    upd(id, "msg", "上传 " + p.getName());
                    fire("state", state());
                    engine.uploadAsset(repo, relObj, p, prog);
                }
                if (!parts.isEmpty() && parts.get(0) != src) {
                    for (File p : parts) p.delete();
                    parts.get(0).getParentFile().delete();
                }
                upd(id, "status", "success");
                upd(id, "msg", "发布 " + parts.size() + " 个资产");
                upd(id, "url", relObj.optString("html_url"));
            } else {
                List<Object[]> items = Engine.collect(src, rel);
                upd(id, "msg", "构建 " + items.size() + " 个文件");
                fire("state", state());
                String sha = engine.commitFiles(repo, branch, items, "WenPush: " + src.getName() + " (" + items.size() + " files)", prog);
                upd(id, "status", "success");
                upd(id, "msg", "提交成功 " + items.size() + " 文件");
                upd(id, "url", "https://github.com/" + api.owner + "/" + repo + "/tree/" + branch);
                upd(id, "commit", sha);
            }
        } catch (Exception e) {
            upd(id, "status", "failed");
            upd(id, "msg", "失败: " + e.getMessage());
        }
        upd(id, "done", -1);
        fire("state", state());
        fire("toast", "任务结束");
    }
}
