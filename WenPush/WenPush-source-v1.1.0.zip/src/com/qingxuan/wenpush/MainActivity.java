package com.qingxuan.wenpush;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;

/** WenPush 主界面 —— 青玄 */
public class MainActivity extends Activity {

    static final int REQ_FILE = 1001;
    static final int REQ_TREE = 1002;
    static final int REQ_PERM = 1003;

    WebView web;
    Bridge bridge;
    LinearLayout root;
    TextView statusBar;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0D1117);
        getWindow().setNavigationBarColor(0xFF0D1117);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0D1117);

        statusBar = new TextView(this);
        statusBar.setTextColor(0xFF8B949E);
        statusBar.setTextSize(11);
        statusBar.setPadding(24, 18, 24, 14);
        statusBar.setText("正在初始化...");
        root.addView(statusBar, new LinearLayout.LayoutParams(-1, -2));

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);

        bridge = new Bridge(this, new Bridge.Emit() {
            public void send(final String json) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (web == null) return;
                        web.evaluateJavascript("window.onNative(" + json + ")", null);
                    }
                });
            }
        });

        web.addJavascriptInterface(new Api(), "WenPush");
        web.loadUrl("file:///android_asset/index.html");

        requestStorage();
    }


    /** 反射判断是否已获“所有文件访问”权限（避开 API 30 编译期依赖） */
    static boolean hasAllFiles() {
        if (Build.VERSION.SDK_INT < 30) return true;
        try {
            java.lang.reflect.Method m = Environment.class.getMethod("isExternalStorageManager");
            Object r = m.invoke(null);
            return r instanceof Boolean && (Boolean) r;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 跳转“所有文件访问”设置页 */
    void openAllFilesSettings() {
        String act = "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION";
        try {
            Intent i = new Intent(act);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_PERM);
            return;
        } catch (Throwable t) {}
        try {
            startActivityForResult(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"), REQ_PERM);
        } catch (Throwable t) {}
    }

    void requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (!hasAllFiles()) {
                statusBar.setText("需授权“所有文件访问”以直接读写 /sdcard");
                openAllFilesSettings();
            } else {
                statusBar.setText("存储权限已就绪");
            }
        } else {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PERM) {
            if (hasAllFiles()) {
                statusBar.setText("存储权限已就绪");
            } else {
                statusBar.setText("未授权：可直接粘贴路径，或点“选择文件”") ;
            }
            return;
        }
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        final int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, takeFlags); } catch (Exception e) {}
        new Thread(new Runnable() {
            public void run() {
                String path = copyToPrivate(uri, req == REQ_TREE);
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (path != null) {
                            web.evaluateJavascript("window.onPicked(" + JSONObject.quote(path) + ")", null);
                        }
                    }
                });
            }
        }).start();
    }
    /** SAF 选择的内容拷到私有目录，返回真实路径供引擎使用 */
    String copyToPrivate(Uri uri, boolean isTree) {
        try {
            File dir = new File(getCacheDir(), "picked");
            if (!dir.exists()) dir.mkdirs();
            String name = queryName(uri);
            if (isTree) {
                File sub = new File(dir, name == null ? "tree" : name);
                if (sub.exists()) sub = new File(dir, (name == null ? "tree" : name) + "_" + System.currentTimeMillis());
                sub.mkdirs();
                copyTree(uri, sub);
                return sub.getAbsolutePath();
            }
            File out = new File(dir, name == null ? ("file_" + System.currentTimeMillis()) : name);
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return null;
            FileOutputStream fo = new FileOutputStream(out);
            byte[] buf = new byte[262144];
            int n;
            while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
            in.close();
            fo.close();
            return out.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    String queryName(Uri uri) {
        try {
            android.database.Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex("display_name");
                String nm = i >= 0 ? c.getString(i) : null;
                c.close();
                if (nm != null) return nm;
            }
        } catch (Exception e) {}
        String p = uri.getLastPathSegment();
        return p == null ? null : new File(p).getName();
    }

    void copyTree(Uri treeUri, File dest) {
        try {
            Uri doc = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri,
                    android.provider.DocumentsContract.getTreeDocumentId(treeUri));
            copyDocChildren(doc, dest);
        } catch (Exception e) {}
    }

    void copyDocChildren(Uri docUri, File dest) {
        try {
            Uri children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(docUri,
                    android.provider.DocumentsContract.getDocumentId(docUri));
            android.database.Cursor c = getContentResolver().query(children,
                    new String[]{"document_id", "display_name", "mime_type"}, null, null, null);
            if (c == null) return;
            while (c.moveToNext()) {
                String id = c.getString(0);
                String nm = c.getString(1);
                String mime = c.getString(2);
                Uri child = android.provider.DocumentsContract.buildDocumentUriUsingTree(docUri, id);
                if (mime != null && mime.contains("directory")) {
                    File sub = new File(dest, nm);
                    sub.mkdirs();
                    copyDocChildren(child, sub);
                } else {
                    InputStream in = getContentResolver().openInputStream(child);
                    if (in == null) continue;
                    FileOutputStream fo = new FileOutputStream(new File(dest, nm));
                    byte[] buf = new byte[262144];
                    int n;
                    while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
                    in.close();
                    fo.close();
                }
            }
            c.close();
        } catch (Exception e) {}
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /** JS 调用入口 */
    class Api {
        @JavascriptInterface
        public String state() { return bridge.state(); }

        @JavascriptInterface
        public void saveConfig(String t, String o, String r, String br) { bridge.saveConfig(t, o, r, br); }

        @JavascriptInterface
        public void push(String paths, String repo, String branch, String rel, String mode) {
            bridge.push(paths, repo, branch, rel, mode);
        }

        @JavascriptInterface
        public void toast(String m) {
            final String msg = m;
            runOnUiThread(new Runnable() { public void run() { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show(); }});
        }

        @JavascriptInterface
        public void pickFile() {
            runOnUiThread(new Runnable() { public void run() {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, REQ_FILE);
            }});
        }

        @JavascriptInterface
        public void pickDir() {
            runOnUiThread(new Runnable() { public void run() {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, REQ_TREE);
            }});
        }

        @JavascriptInterface
        public void openUrl(String u) {
            final String url = u;
            runOnUiThread(new Runnable() { public void run() {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) {}
            }});
        }


        @JavascriptInterface
        public void listDir(String repo, String path, String ref) {
            bridge.listDir(repo, path, ref);
        }

        @JavascriptInterface
        public void listReleases(String repo) {
            bridge.listReleases(repo);
        }

        @JavascriptInterface
        public void download(String kind, String repo, String path, String url, String name, String destDir) {
            bridge.download(kind, repo, path, url, name, destDir);
        }

        @JavascriptInterface
        public String defaultDest() {
            return android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/Download/WenPush";
        }

        @JavascriptInterface
        public void perm() { runOnUiThread(new Runnable() { public void run() { requestStorage(); }}); }

        @JavascriptInterface
        public String env() {
            try {
                JSONObject o = new JSONObject();
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("allFiles", hasAllFiles());
                o.put("sdcard", new File("/sdcard").canRead());
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }
    }
}
