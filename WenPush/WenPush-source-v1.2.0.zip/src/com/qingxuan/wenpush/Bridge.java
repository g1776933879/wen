package com.qingxuan.wenpush;

import android.content.*;
import android.net.Uri;
import android.webkit.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** WebView JS 桥 —— 青玄 */
public class Bridge {

    public interface Emit { void send(String json); }

    private final Context ctx;
    private final Emit emit;
    private final GithubApi api = new GithubApi();
    private Engine engine;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Map<String, JSONObject> tasks = new LinkedHashMap<String, JSONObject>();
    private final List<String> order = new ArrayList<String>();
    private SharedPreferences sp;

    public Bridge(Context c, Emit e) {
        ctx = c;
        emit = e;
        sp = c.getSharedPreferences("wenpush", Context.MODE_PRIVATE);
        api.token = sp.getString("token", "").trim();
        api.owner = sp.getString("owner", "");
        engine = new Engine(api, new File(c.getCacheDir(), "tmp"));
    }

    void fire(String type, Object payload) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("payload", payload);
            emit.send(o.toString());
        } catch (Exception e) {}
    }

    public String state() {
        try {
            JSONObject o = new JSONObject();
            o.put("owner", api.owner);
            o.put("token_hint", api.token.length() > 12 ? api.token.substring(0, 7) + "..." + api.token.substring(api.token.length() - 4) : "");
            o.put("has_token", api.token.length() > 0);
            o.put("default_repo", sp.getString("repo", ""));
            o.put("branch", sp.getString("branch", "main"));
            JSONArray arr = new JSONArray();
            synchronized (tasks) {
                List<String> rev = new ArrayList<String>(order);
                Collections.reverse(rev);
                for (String id : rev) arr.put(tasks.get(id));
            }
            o.put("tasks", arr);
            o.put("git_max", Engine.GIT_MAX);
            o.put("git_huge", Engine.GIT_HUGE);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    public void saveConfig(String token, String owner, String repo, String branch) {
        SharedPreferences.Editor ed = sp.edit();
        if (token != null && token.length() > 0) { api.token = token.trim(); ed.putString("token", api.token); }
        if (owner != null && owner.length() > 0) { api.owner = owner.trim(); ed.putString("owner", api.owner); }
        if (repo != null && repo.length() > 0) ed.putString("repo", repo.trim());
        if (branch != null && branch.length() > 0) ed.putString("branch", branch.trim());
        ed.apply();
        fire("toast", "配置已保存");
        fire("state", state());
    }
    public void push(final String pathsJson, final String repo, final String branch,
                     final String rel, final String mode) {
        try {
            JSONArray arr = new JSONArray(pathsJson);
            for (int i = 0; i < arr.length(); i++) {
                String path = arr.getString(i).trim();
                if (path.isEmpty()) continue;
                final File f = new File(path);
                if (!f.exists()) { fire("toast", "路径不存在: " + path); continue; }
                final String id = "t" + System.currentTimeMillis() + (int) (Math.random() * 999);
                JSONObject t = new JSONObject();
                t.put("id", id);
                t.put("name", f.getName());
                t.put("size", f.isFile() ? f.length() : dirSize(f));
                t.put("done", 0);
                t.put("status", "pending");
                t.put("msg", "排队中");
                t.put("channel", Engine.channel(t.getLong("size"), mode));
                synchronized (tasks) { tasks.put(id, t); order.add(id); }
                fire("state", state());
                pool.submit(new Runnable() { public void run() {
                    runTask(id, f, repo, branch, rel, mode);
                }});
            }
        } catch (Exception e) {
            fire("toast", "提交失败: " + e.getMessage());
        }
    }

    static long dirSize(File d) {
        long n = 0;
        File[] fs = d.listFiles();
        if (fs == null) return 0;
        for (File f : fs) n += f.isDirectory() ? dirSize(f) : f.length();
        return n;
    }

    void upd(String id, String key, Object val) {
        synchronized (tasks) {
            JSONObject t = tasks.get(id);
            if (t == null) return;
            try { t.put(key, val); } catch (Exception e) {}
        }
    }

    void runTask(String id, File src, String repo, String branch, String rel, String mode) {
        try {
            if (repo == null || repo.isEmpty()) repo = sp.getString("repo", "");
            if (branch == null || branch.isEmpty()) branch = sp.getString("branch", "main");
            if (api.token.isEmpty()) throw new IOException("未配置 Token");
            if (repo == null || repo.isEmpty()) throw new IOException("未指定仓库");

            long size = src.isFile() ? src.length() : dirSize(src);
            String ch = Engine.channel(size, mode);
            upd(id, "status", "running");
            upd(id, "channel", ch);
            upd(id, "msg", "开始处理");
            fire("state", state());

            final String tid = id;
            final long t0 = System.currentTimeMillis();
            GithubApi.Progress prog = new GithubApi.Progress() {
                public void on(long done, long total) {
                    upd(tid, "done", done);
                    long el = System.currentTimeMillis() - t0;
                    if (el > 300) upd(tid, "speed", done * 1000.0 / el);
                    fire("state", state());
                }
            };

            if ("release".equals(ch)) {
                String tag = sp.getString("tagprefix", "push") + "-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
                upd(id, "msg", "分卷检查");
                fire("state", state());
                List<File> parts = engine.split(src);
                JSONObject relObj = engine.getOrCreateRelease(repo, tag);
                for (File p : parts) {
                    upd(id, "msg", "上传 " + p.getName());
                    fire("state", state());
                    engine.uploadAsset(repo, relObj, p, prog);
                }
                if (!parts.isEmpty() && parts.get(0) != src) {
                    for (File p : parts) p.delete();
                    parts.get(0).getParentFile().delete();
                }
                upd(id, "status", "success");
                upd(id, "msg", "发布 " + parts.size() + " 个资产");
                upd(id, "url", relObj.optString("html_url"));
            } else {
                List<Object[]> items = Engine.collect(src, rel);
                upd(id, "msg", "构建 " + items.size() + " 个文件");
                fire("state", state());
                String sha = engine.commitFiles(repo, branch, items, "WenPush: " + src.getName() + " (" + items.size() + " files)", prog);
                upd(id, "status", "success");
                upd(id, "msg", "提交成功 " + items.size() + " 文件");
                upd(id, "url", "https://github.com/" + api.owner + "/" + repo + "/tree/" + branch);
                upd(id, "commit", sha);
            }
        } catch (Exception e) {
            upd(id, "status", "failed");
            upd(id, "msg", "失败: " + e.getMessage());
        }
        upd(id, "done", -1);
        fire("state", state());
        fire("toast", "任务结束");
    }

    // ────────────── 下载 ──────────────

    public void listDir(final String repo, final String path, final String ref) {
        pool.submit(new Runnable() { public void run() {
            try {
                if (api.token.isEmpty()) throw new IOException("未配置 Token");
                JSONArray a = engine.listDir(repo, path, ref);
                fire("listing", a.toString());
            } catch (Exception e) {
                fire("toast", "浏览失败: " + e.getMessage());
            }
        }});
    }

    public void listReleases(final String repo) {
        pool.submit(new Runnable() { public void run() {
            try {
                if (api.token.isEmpty()) throw new IOException("未配置 Token");
                JSONArray a = engine.listReleases(repo);
                JSONArray out = new JSONArray();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject r = a.getJSONObject(i);
                    JSONObject o = new JSONObject();
                    o.put("tag", r.optString("tag_name"));
                    o.put("name", r.optString("name"));
                    o.put("time", r.optString("published_at"));
                    JSONArray as = r.optJSONArray("assets");
                    JSONArray la = new JSONArray();
                    if (as != null) {
                        for (int j = 0; j < as.length(); j++) {
                            JSONObject x = as.getJSONObject(j);
                            JSONObject y = new JSONObject();
                            y.put("name", x.optString("name"));
                            y.put("size", x.optLong("size"));
                            y.put("url", x.optString("browser_download_url"));
                            y.put("id", x.optLong("id"));
                            la.put(y);
                        }
                    }
                    o.put("assets", la);
                    out.put(o);
                }
                fire("releases", out.toString());
            } catch (Exception e) {
                fire("toast", "获取发布列表失败: " + e.getMessage());
            }
        }});
    }

    /** kind: repo=仓库文件, release=发布资产 */
    public void download(final String kind, final String repo, final String path,
                         final String url, final String name, final String destDir) {
        final String id = "d" + System.currentTimeMillis() + (int) (Math.random() * 999);
        try {
            JSONObject t = new JSONObject();
            t.put("id", id);
            t.put("name", name);
            t.put("size", 0);
            t.put("done", 0);
            t.put("status", "pending");
            t.put("msg", "排队下载");
            t.put("channel", "download");
            t.put("dir", "down");
            synchronized (tasks) { tasks.put(id, t); order.add(id); }
            fire("state", state());
        } catch (Exception e) { return; }

        pool.submit(new Runnable() { public void run() {
            try {
                if (api.token.isEmpty()) throw new IOException("未配置 Token");
                File dir = new File(destDir == null || destDir.isEmpty()
                        ? android.os.Environment.getExternalStorageDirectory() + "/Download/WenPush"
                        : destDir);
                dir.mkdirs();
                File dest = new File(dir, name);
                upd(id, "status", "running");
                upd(id, "msg", "下载中");
                upd(id, "dest", dest.getAbsolutePath());
                fire("state", state());

                final String tid = id;
                final long t0 = System.currentTimeMillis();
                GithubApi.Progress prog = new GithubApi.Progress() {
                    public void on(long done, long total) {
                        upd(tid, "done", done);
                        upd(tid, "size", total);
                        long el = System.currentTimeMillis() - t0;
                        if (el > 300) upd(tid, "speed", done * 1000.0 / el);
                        fire("state", state());
                    }
                };

                long n;
                if ("release".equals(kind)) {
                    n = engine.downloadFile(url, dest, prog);
                } else {
                    n = engine.downloadRepoFile(repo, path, null, dest, prog);
                }
                upd(id, "status", "success");
                upd(id, "msg", "已保存 " + fmtSize(n));
                upd(id, "size", n);
                upd(id, "done", n);
                fire("toast", "下载完成: " + dest.getName());
            } catch (Exception e) {
                upd(id, "status", "failed");
                upd(id, "msg", "失败: " + e.getMessage());
            }
            fire("state", state());
        }});
    }

    static String fmtSize(long n) {
        if (n < 1024) return n + " B";
        if (n < 1048576) return String.format("%.1f KB", n / 1024.0);
        if (n < 1073741824L) return String.format("%.2f MB", n / 1048576.0);
        return String.format("%.2f GB", n / 1073741824.0);
    }

    /** 递归列出目录内容，供前端预览 */
    public void listTree(final String repo, final String path, final String ref) {
        pool.submit(new Runnable() { public void run() {
            try {
                if (api.token.isEmpty()) throw new IOException("未配置 Token");
                JSONArray a = engine.listTree(repo, path, ref);
                fire("tree", a.toString());
            } catch (Exception e) {
                fire("toast", "列举失败: " + e.getMessage());
            }
        }});
    }

    /**
     * 下载整个文件夹（递归）。
     * 保留仓库内目录结构，失败文件跳过并记录，最后汇总报告。
     */
    public void downloadFolder(final String repo, final String path, final String ref, final String destDir) {
        final String id = "f" + System.currentTimeMillis() + (int) (Math.random() * 999);
        final String folderName = (path == null || path.isEmpty())
                ? repo : path.substring(path.lastIndexOf('/') + 1);
        try {
            JSONObject t = new JSONObject();
            t.put("id", id);
            t.put("name", folderName);
            t.put("size", 0);
            t.put("done", 0);
            t.put("status", "pending");
            t.put("msg", "准备下载文件夹");
            t.put("channel", "download");
            t.put("dir", "down");
            t.put("files", 0);
            t.put("ok", 0);
            t.put("fail", 0);
            synchronized (tasks) { tasks.put(id, t); order.add(id); }
            fire("state", state());
        } catch (Exception e) { return; }

        pool.submit(new Runnable() { public void run() {
            try {
                if (api.token.isEmpty()) throw new IOException("未配置 Token");
                upd(id, "status", "running");
                upd(id, "msg", "枚举文件...");
                fire("state", state());

                JSONArray list = engine.listTree(repo, path, ref);
                int total = list.length();
                if (total == 0) throw new IOException("该目录为空");

                long totalBytes = 0;
                for (int i = 0; i < total; i++) totalBytes += list.getJSONObject(i).optLong("size");
                upd(id, "files", total);
                upd(id, "size", totalBytes);

                File base = new File(destDir == null || destDir.isEmpty()
                        ? android.os.Environment.getExternalStorageDirectory() + "/Download/WenPush"
                        : destDir);
                base.mkdirs();

                final String tid = id;
                long doneBytes = 0;
                int ok = 0, fail = 0;
                StringBuilder errs = new StringBuilder();

                for (int i = 0; i < total; i++) {
                    JSONObject f = list.getJSONObject(i);
                    String rel = f.optString("rel", f.optString("path"));
                    String name = f.optString("name");
                    long sz = f.optLong("size");
                    final int idx = i + 1;
                    upd(id, "msg", "[" + idx + "/" + total + "] " + name);
                    fire("state", state());

                    File dest = new File(base, rel);
                    if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
                    try {
                        engine.downloadRepoFile(repo, f.optString("path"), ref, dest, null);
                        ok++;
                        doneBytes += sz;
                        upd(id, "ok", ok);
                        upd(id, "done", doneBytes);
                    } catch (Exception e) {
                        fail++;
                        upd(id, "fail", fail);
                        if (errs.length() < 300) errs.append(name).append(" ");
                    }
                    fire("state", state());
                }

                if (fail == 0) {
                    upd(id, "status", "success");
                    upd(id, "msg", "完成 " + ok + " 个文件 -> " + base.getAbsolutePath());
                    fire("toast", "文件夹下载完成: " + ok + " 个文件");
                } else if (ok > 0) {
                    upd(id, "status", "success");
                    upd(id, "msg", "部分完成 " + ok + " 成功 / " + fail + " 失败");
                    fire("toast", ok + " 个成功, " + fail + " 个失败");
                } else {
                    upd(id, "status", "failed");
                    upd(id, "msg", "全部失败: " + errs);
                }
                upd(id, "dest", base.getAbsolutePath());
            } catch (Exception e) {
                upd(id, "status", "failed");
                upd(id, "msg", "失败: " + e.getMessage());
            }
            fire("state", state());
        }});
    }
}
