package com.qingxuan.wenpush;

import org.json.JSONObject;
import java.io.*;
import java.net.*;

/** GitHub REST API 客户端 —— 青玄 */
public class GithubApi {

    public static final String API = "https://api.github.com";
    public static final String UPLOADS = "https://uploads.github.com";
    public static final String UA = "WenPush/1.0";

    public String token = "";
    public String owner = "";

    public interface Progress { void on(long done, long total); }

    private HttpURLConnection open(String method, String url, boolean big) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(20000);
        c.setReadTimeout(big ? 3600000 : 120000);
        c.setRequestProperty("Authorization", "token " + token);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        c.setInstanceFollowRedirects(true);
        return c;
    }

    public String call(String method, String path, String json) throws IOException {
        return callRetry(method, path, json, 4);
    }

    private String callRetry(String method, String path, String json, int tries) throws IOException {
        IOException last = null;
        for (int i = 0; i < tries; i++) {
            try {
                return once(method, path, json);
            } catch (ApiException e) {
                if (e.code < 500 && e.code != 403 && e.code != 429) throw e;
                last = e;
            } catch (IOException e) {
                last = e;
            }
            if (i < tries - 1) {
                try { Thread.sleep(Math.min(1000L << i, 15000L)); } catch (InterruptedException ie) {}
            }
        }
        throw last == null ? new IOException("unknown") : last;
    }

    private String once(String method, String path, String json) throws IOException {
        String url = path.startsWith("http") ? path : API + path;
        HttpURLConnection c = open(method, url, false);
        if (json != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            byte[] b = json.getBytes("UTF-8");
            c.setFixedLengthStreamingMode(b.length);
            OutputStream os = c.getOutputStream();
            os.write(b);
            os.flush();
            os.close();
        }
        return read(c);
    }

    private String read(HttpURLConnection c) throws IOException {
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        String body = is == null ? "" : slurp(is);
        if (code < 200 || code >= 300) throw new ApiException(code, pretty(body));
        return body;
    }

    private String pretty(String body) {
        try {
            JSONObject o = new JSONObject(body);
            String m = o.optString("message", body);
            if (o.has("errors")) m = m + " | " + o.optString("errors");
            return m;
        } catch (Exception e) { return body; }
    }

    static String slurp(InputStream is) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        is.close();
        return new String(bo.toByteArray(), "UTF-8");
    }

    /** 上传 Release 资产，流式带进度 */
    public String uploadAsset(String repo, long releaseId, File f, Progress p) throws IOException {
        String name = enc(f.getName());
        String url = UPLOADS + "/repos/" + owner + "/" + repo + "/releases/" + releaseId + "/assets?name=" + name;
        long size = f.length();
        IOException last = null;
        for (int t = 0; t < 4; t++) {
            try {
                HttpURLConnection c = open("POST", url, true);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/octet-stream");
                c.setFixedLengthStreamingMode(size);
                OutputStream os = c.getOutputStream();
                FileInputStream fi = new FileInputStream(f);
                byte[] buf = new byte[262144];
                long done = 0;
                int n;
                while ((n = fi.read(buf)) > 0) {
                    os.write(buf, 0, n);
                    done += n;
                    if (p != null) p.on(done, size);
                }
                fi.close();
                os.flush();
                os.close();
                return read(c);
            } catch (ApiException e) {
                if (e.code < 500 && e.code != 403 && e.code != 429) throw e;
                last = e;
            } catch (IOException e) { last = e; }
            if (t < 3) { try { Thread.sleep(Math.min(1000L << t, 15000L)); } catch (InterruptedException ie) {} }
        }
        throw last == null ? new IOException("upload failed") : last;
    }

    public static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
        catch (Exception e) { return s; }
    }

    public static class ApiException extends IOException {
        public int code;
        public ApiException(int c, String m) { super("HTTP " + c + ": " + m); this.code = c; }
    }
}
