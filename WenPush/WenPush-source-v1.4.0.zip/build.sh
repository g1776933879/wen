#!/bin/bash
# WenPush APK 构建脚本 —— 青玄
set -u
cd "$(dirname "$0")"

PLATFORM=/usr/lib/android-sdk/platforms/android-23/android.jar
BT=/opt/android-sdk/build-tools/34.0.0
OUT=build

rm -rf $OUT
mkdir -p $OUT/gen $OUT/classes $OUT/dex

echo "[1/6] 编译资源"
aapt2 compile --dir res -o $OUT/res.zip || exit 1

echo "[2/6] 链接资源 + 生成 R.java"
aapt2 link -o $OUT/base.apk \
  -I $PLATFORM \
  --manifest AndroidManifest.xml \
  -A assets \
  --java $OUT/gen \
  --min-sdk-version 23 \
  --target-sdk-version 23 \
  --version-code 5 \
  --version-name 1.4.0 \
  $OUT/res.zip || exit 1

echo "[3/6] 编译 Java"
SRCS=$(find src $OUT/gen -name '*.java' | tr '\n' ' ')
javac -encoding UTF-8 -source 8 -target 8 -nowarn \
  -bootclasspath $PLATFORM -cp $PLATFORM \
  -d $OUT/classes $SRCS > $OUT/javac.log 2>&1
JRC=$?
if [ $JRC -ne 0 ]; then
  echo 'Java 编译失败:'
  head -40 $OUT/javac.log
  exit 1
fi
echo "  class 文件: $(find $OUT/classes -name '*.class' | wc -l) 个"

echo "[4/6] 转 dex"
$BT/d8 --release --min-api 23 --lib $PLATFORM \
  --output $OUT/dex $(find $OUT/classes -name '*.class') > $OUT/d8.log 2>&1
if [ ! -f $OUT/dex/classes.dex ]; then echo 'dex 失败:'; head -20 $OUT/d8.log; exit 1; fi
[ -f $OUT/dex/classes.dex ] || { echo 'dex 生成失败'; exit 1; }

echo "[5/6] 打包"
cp $OUT/base.apk $OUT/work.apk
cd $OUT
python3 - << 'PYEOF'
import zipfile, shutil, os
src = 'work.apk'
dst = 'packed.apk'
shutil.copy(src, dst)
z = zipfile.ZipFile(dst, 'a', zipfile.ZIP_DEFLATED)
z.write('dex/classes.dex', 'classes.dex')
z.close()
print('  classes.dex 已注入')
PYEOF
cd ..

echo "[6/6] 对齐 + 签名"
zipalign -f 4 $OUT/packed.apk $OUT/aligned.apk || exit 1
apksigner sign --ks wenpush.keystore --ks-pass pass:wenpush2026 \
  --key-pass pass:wenpush2026 --ks-key-alias wenpush \
  --min-sdk-version 23 \
  --out $OUT/WenPush-v1.4.0.apk $OUT/aligned.apk || exit 1

apksigner verify --print-certs $OUT/WenPush-v1.4.0.apk 2>&1 | head -5
echo ''
ls -la $OUT/WenPush-v1.4.0.apk
