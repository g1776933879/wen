import json, urllib.request, urllib.parse, os
TOKEN = open('/root/wenpush/config.json').read()
try:
    TOKEN = json.loads(TOKEN)['token']
except Exception:
    TOKEN = open('/root/yuhua-sync/config.env').read().split('TOKEN=')[1].split('\n')[0].strip().strip('"')
OWNER, REPO, BR = 'g1776933879', 'wen', 'main'
API = 'https://api.github.com'
KEEP = ('v1.4.0',)

def call(method, path, data=None):
    req = urllib.request.Request(API + path, method=method,
        headers={'Authorization':'token '+TOKEN,'Accept':'application/vnd.github+json','User-Agent':'WenPush'},
        data=json.dumps(data).encode() if data else None)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            b = r.read(); return r.status, (json.loads(b) if b else None)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()[:200]

# 删仓库里旧版文件
st, tree = call('GET','/repos/%s/%s/git/trees/%s?recursive=1'%(OWNER,REPO,BR))
del_paths=[]
for x in tree.get('tree',[]):
    if x['type']!='blob': continue
    p=x['path']
    if not p.startswith('WenPush/'): continue
    if any(k in p for k in KEEP): continue
    del_paths.append((p,x['sha']))
print('待删仓库文件:', [p for p,_ in del_paths])
for p,sha in del_paths:
    st,_ = call('DELETE','/repos/%s/%s/contents/%s'%(OWNER,REPO,urllib.parse.quote(p)),
                {'message':'清理旧版本 '+p,'sha':sha,'branch':BR})
    print('  del',p,'->',st)

# 删旧 Release
st, rels = call('GET','/repos/%s/%s/releases?per_page=100'%(OWNER,REPO))
for r in rels or []:
    if any(k in r['tag_name'] for k in KEEP): continue
    st,_ = call('DELETE','/repos/%s/%s/releases/%d'%(OWNER,REPO,r['id']))
    print('  del release',r['tag_name'],'->',st)
    st,_ = call('DELETE','/repos/%s/%s/git/refs/tags/%s'%(OWNER,REPO,urllib.parse.quote(r['tag_name'])))
    print('    del tag ->',st)
