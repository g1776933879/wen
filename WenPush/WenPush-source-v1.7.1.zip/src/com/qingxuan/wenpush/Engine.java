package com.qingxuan.wenpush;

import org.json.*;
import java.io.*;

/** 推送引擎：三条通道自动分流 —— 青玄 */
public class Engine {

    public static final long GIT_MAX = 32L * 1024 * 1024;
    public static final long GIT_HUGE = 95L * 1024 * 1024;
    public static final long PART_SIZE = 1800L * 1024 * 1024;

    /** 同仓库+分支串行锁，避免并发提交报 fast-forward 错误 */
    private static final java.util.concurrent.ConcurrentHashMap<String, Object> LOCKS =
            new java.util.concurrent.ConcurrentHashMap<String, Object>();

    private static Object lockFor(String repo, String branch) {
        String k = repo + "@" + branch;
        Object o = LOCKS.get(k);
        if (o == null) {
            Object n = new Object();
            Object prev = LOCKS.putIfAbsent(k, n);
            o = prev == null ? n : prev;
        }
        return o;
    }

    private final GithubApi api;
    private final File tmpDir;

    public Engine(GithubApi api, File tmpDir) {
        this.api = api;
        this.tmpDir = tmpDir;
        if (!tmpDir.exists()) tmpDir.mkdirs();
    }

    public static String channel(long size, String mode) {
        if (mode != null && !mode.isEmpty() && !"auto".equals(mode)) return mode;
        if (size <= GIT_MAX) return "git";
        if (size <= GIT_HUGE) return "git-huge";
        return "release";
    }

    public String rp(String repo) { return "/repos/" + api.owner + "/" + repo; }

    public String getRef(String repo, String branch) throws Exception {
        try {
            JSONObject d = new JSONObject(api.call("GET", rp(repo) + "/git/ref/heads/" + branch, null));
            return d.getJSONObject("object").getString("sha");
        } catch (GithubApi.ApiException e) {
            if (e.code == 404) return null;
            throw e;
        }
    }

    public String ensureBranch(String repo, String branch) throws Exception {
        String sha = getRef(repo, branch);
        if (sha != null) return sha;
        JSONObject info = new JSONObject(api.call("GET", rp(repo), null));
        String dflt = info.optString("default_branch", "main");
        String base = getRef(repo, dflt);
        if (base != null) {
            JSONObject b = new JSONObject();
            b.put("ref", "refs/heads/" + branch);
            b.put("sha", base);
            api.call("POST", rp(repo) + "/git/refs", b.toString());
            return base;
        }
        JSONObject b0 = new JSONObject();
        b0.put("content", "WenPush init\n");
        b0.put("encoding", "utf-8");
        String blob = new JSONObject(api.call("POST", rp(repo) + "/git/blobs", b0.toString())).getString("sha");
        JSONObject e0 = new JSONObject();
        e0.put("path", ".wenpush"); e0.put("mode", "100644"); e0.put("type", "blob"); e0.put("sha", blob);
        JSONObject t0 = new JSONObject();
        t0.put("tree", new JSONArray().put(e0));
        String tree = new JSONObject(api.call("POST", rp(repo) + "/git/trees", t0.toString())).getString("sha");
        JSONObject c0 = new JSONObject();
        c0.put("message", "init by WenPush"); c0.put("tree", tree);
        String cm = new JSONObject(api.call("POST", rp(repo) + "/git/commits", c0.toString())).getString("sha");
        JSONObject r0 = new JSONObject();
        r0.put("ref", "refs/heads/" + branch); r0.put("sha", cm);
        api.call("POST", rp(repo) + "/git/refs", r0.toString());
        return cm;
    }

    /** 文件转 blob；大文件流式写临时 base64 避免 OOM */
    public String blobFromFile(String repo, File f) throws Exception {
        long size = f.length();
        if (size <= GIT_MAX) {
            byte[] data = readAll(f);
            JSONObject o = new JSONObject();
            o.put("content", android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP));
            o.put("encoding", "base64");
            return new JSONObject(api.call("POST", rp(repo) + "/git/blobs", o.toString())).getString("sha");
        }
        File t = new File(tmpDir, "b64_" + System.currentTimeMillis() + "_" + f.getName());
        FileOutputStream fo = new FileOutputStream(t);
        fo.write("{\"encoding\":\"base64\",\"content\":\"".getBytes("UTF-8"));
        FileInputStream fi = new FileInputStream(f);
        byte[] buf = new byte[3 * 1024 * 1024];
        // read() 不保证填满缓冲区；中间块必须是 3 的倍数，否则 base64 padding 会错位
        byte[] carry = new byte[3];
        int carryLen = 0;
        int n;
        while ((n = fi.read(buf)) > 0) {
            int total = carryLen + n;
            int use = total - (total % 3);
            if (use > 0) {
                byte[] enc = new byte[use];
                int fromBuf = use - carryLen;
                if (carryLen > 0) System.arraycopy(carry, 0, enc, 0, carryLen);
                if (fromBuf > 0) System.arraycopy(buf, 0, enc, carryLen, fromBuf);
                fo.write(android.util.Base64.encode(enc, android.util.Base64.NO_WRAP));
            }
            carryLen = total - use;
            if (carryLen > 0) System.arraycopy(buf, n - carryLen, carry, 0, carryLen);
        }
        if (carryLen > 0) {
            byte[] tail = new byte[carryLen];
            System.arraycopy(carry, 0, tail, 0, carryLen);
            fo.write(android.util.Base64.encode(tail, android.util.Base64.NO_WRAP));
        }
        fi.close();
        fo.write("\"}".getBytes("UTF-8"));
        fo.close();
        try {
            String body = new String(readAll(t), "UTF-8");
            return new JSONObject(api.call("POST", rp(repo) + "/git/blobs", body)).getString("sha");
        } finally { t.delete(); }
    }

    static byte[] readAll(File f) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        FileInputStream fi = new FileInputStream(f);
        byte[] buf = new byte[262144];
        int n;
        while ((n = fi.read(buf)) > 0) bo.write(buf, 0, n);
        fi.close();
        return bo.toByteArray();
    }


    /** 单文件或目录递归收集 -> [(File, repoPath)] */
    public static java.util.List<Object[]> collect(File src, String rel) {
        java.util.List<Object[]> out = new java.util.ArrayList<Object[]>();
        if (src.isFile()) {
            String base = src.getName();
            String r = (rel == null || rel.isEmpty()) ? base : rel + "/" + base;
            out.add(new Object[]{src, r});
            return out;
        }
        String root = src.getName();
        walk(src, src, rel, root, out);
        return out;
    }

    private static void walk(File base, File dir, String rel, String root, java.util.List<Object[]> out) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        java.util.Arrays.sort(fs);
        for (File f : fs) {
            if (f.getName().startsWith(".")) continue;
            if (f.isDirectory()) { walk(base, f, rel, root, out); continue; }
            String rp = base.toURI().relativize(f.toURI()).getPath();
            String r = (rel == null || rel.isEmpty()) ? root + "/" + rp : rel + "/" + rp;
            out.add(new Object[]{f, r});
        }
    }

    /** 原子提交：多文件一次 commit */
    public String commitFiles(String repo, String branch, java.util.List<Object[]> items,
                              String message, GithubApi.Progress p) throws Exception {
        synchronized (lockFor(repo, branch)) {
            return commitLocked(repo, branch, items, message, p);
        }
    }

    private String commitLocked(String repo, String branch, java.util.List<Object[]> items,
                                String message, GithubApi.Progress p) throws Exception {
        String baseSha = ensureBranch(repo, branch);
        JSONObject base = new JSONObject(api.call("GET", rp(repo) + "/git/commits/" + baseSha, null));
        String baseTree = base.getJSONObject("tree").getString("sha");
        JSONArray entries = new JSONArray();
        long done = 0, total = 0;
        for (Object[] it : items) total += ((File) it[0]).length();
        for (Object[] it : items) {
            File f = (File) it[0];
            String sha = blobFromFile(repo, f);
            JSONObject e = new JSONObject();
            e.put("path", (String) it[1]);
            e.put("mode", "100644");
            e.put("type", "blob");
            e.put("sha", sha);
            entries.put(e);
            done += f.length();
            if (p != null) p.on(done, total);
        }
        JSONObject t = new JSONObject();
        t.put("base_tree", baseTree);
        t.put("tree", entries);
        String newTree = new JSONObject(api.call("POST", rp(repo) + "/git/trees", t.toString())).getString("sha");
        JSONObject c = new JSONObject();
        c.put("message", message);
        c.put("tree", newTree);
        c.put("parents", new JSONArray().put(baseSha));
        String commit = new JSONObject(api.call("POST", rp(repo) + "/git/commits", c.toString())).getString("sha");
        JSONObject u = new JSONObject();
        u.put("sha", commit);
        u.put("force", false);
        api.call("PATCH", rp(repo) + "/git/refs/heads/" + branch, u.toString());
        return commit;
    }

    /** 获取或创建 Release */
    public JSONObject getOrCreateRelease(String repo, String tag) throws Exception {
        try {
            return new JSONObject(api.call("GET", rp(repo) + "/releases/tags/" + GithubApi.enc(tag), null));
        } catch (GithubApi.ApiException e) {
            if (e.code != 404) throw e;
        }
        JSONObject b = new JSONObject();
        b.put("tag_name", tag);
        b.put("name", "WenPush " + tag);
        b.put("body", "由 WenPush 自动发布");
        b.put("draft", false);
        b.put("prerelease", false);
        return new JSONObject(api.call("POST", rp(repo) + "/releases", b.toString()));
    }

    /** 上传资产，同名先删 */
    public JSONObject uploadAsset(String repo, JSONObject release, File f, GithubApi.Progress p) throws Exception {
        long rid = release.getLong("id");
        JSONArray assets = release.optJSONArray("assets");
        if (assets != null) {
            for (int i = 0; i < assets.length(); i++) {
                JSONObject a = assets.getJSONObject(i);
                if (f.getName().equals(a.optString("name"))) {
                    api.call("DELETE", rp(repo) + "/releases/assets/" + a.getLong("id"), null);
                }
            }
        }
        return new JSONObject(api.uploadAsset(repo, rid, f, p));
    }

    /** 分卷 */
    public java.util.List<File> split(File src) throws Exception {
        long size = src.length();
        java.util.List<File> parts = new java.util.ArrayList<File>();
        if (size <= PART_SIZE) { parts.add(src); return parts; }
        File dir = new File(tmpDir, "parts_" + System.currentTimeMillis());
        dir.mkdirs();
        FileInputStream fi = new FileInputStream(src);
        byte[] buf = new byte[1048576];
        int idx = 1;
        long written = 0;
        FileOutputStream fo = null;
        int n;
        while ((n = fi.read(buf)) > 0) {
            if (fo == null) {
                fo = new FileOutputStream(new File(dir, src.getName() + String.format(".part%03d", idx)));
                parts.add(new File(dir, src.getName() + String.format(".part%03d", idx)));
            }
            fo.write(buf, 0, n);
            written += n;
            if (written >= PART_SIZE) { fo.close(); fo = null; written = 0; idx++; }
        }
        if (fo != null) fo.close();
        fi.close();
        return parts;
    }

    /** 列出仓库内容（目录浏览） */
    public org.json.JSONArray listDir(String repo, String path, String ref) throws Exception {
        String p = rp(repo) + "/contents/" + (path == null || path.isEmpty() ? "" : pEnc(path));
        if (ref != null && !ref.isEmpty()) p += "?ref=" + pEnc(ref);
        String body = api.call("GET", p, null);
        return new org.json.JSONArray(body);
    }

    /** 列出全部 Release */
    public org.json.JSONArray listReleases(String repo) throws Exception {
        return new org.json.JSONArray(api.call("GET", rp(repo) + "/releases?per_page=100", null));
    }

    static String pEnc(String s) {
        try { return java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20").replace("%2F", "/"); }
        catch (Exception e) { return s; }
    }

    /** 下载文件到目标路径（带进度）。raw=true 用 contents 原始通道 */
    public long downloadFile(String url, File dest, GithubApi.Progress prog) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestProperty("Authorization", "token " + api.token);
        c.setRequestProperty("User-Agent", GithubApi.UA);
        c.setRequestProperty("Accept", "application/octet-stream");
        c.setConnectTimeout(20000);
        c.setReadTimeout(3600000);
        c.setInstanceFollowRedirects(true);
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) {
            throw new java.io.IOException("HTTP " + code + " 下载失败");
        }
        long total = c.getContentLength();
        if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
        java.io.InputStream in = c.getInputStream();
        java.io.FileOutputStream fo = new java.io.FileOutputStream(dest);
        byte[] buf = new byte[262144];
        long done = 0;
        int n;
        while ((n = in.read(buf)) > 0) {
            fo.write(buf, 0, n);
            done += n;
            if (prog != null) prog.on(done, total > 0 ? total : done);
        }
        in.close();
        fo.close();
        return done;
    }

    /**
     * 下载仓库单文件。
     * 关键：contents API 的 raw 模式对大文件会截断（实测 30MB 只拿到 5MB），
     * 因此改走 blobs API —— 按 tree 中的 sha 取，返回 base64，完整可靠。
     */
    public long downloadRepoFile(String repo, String path, String ref, File dest, GithubApi.Progress prog) throws Exception {
        String r = (ref == null || ref.isEmpty()) ? "main" : ref;
        String sha = blobShaOf(repo, path, r);
        long want = -1;
        try {
            JSONArray tree = new JSONObject(api.call("GET", rp(repo) + "/git/trees/" + getRef(repo, r) + "?recursive=1", null)).optJSONArray("tree");
            if (tree != null) for (int i = 0; i < tree.length(); i++) {
                JSONObject x = tree.getJSONObject(i);
                if ("blob".equals(x.optString("type")) && path.equals(x.optString("path"))) { want = x.optLong("size", -1); break; }
            }
        } catch (Exception ignore) {}

        String err1 = null, err2 = null;
        // 通道1：blobs API（按 sha 取，返回 base64）
        try {
            long n = viaBlobs(repo, sha, dest, prog, want);
            return n;
        } catch (Exception e) { err1 = e.getMessage(); }
        // 通道2：raw 直链（CDN，不经 API 网关）
        try {
            long n = viaRaw(repo, path, r, dest, prog, want);
            return n;
        } catch (Exception e) { err2 = e.getMessage(); }
        // 通道3：contents API（小文件可用）
        try {
            return viaContents(repo, path, r, dest, prog, want);
        } catch (Exception e3) {
            throw new java.io.IOException("三种下载通道均失败 | blobs: " + err1 + " | raw: " + err2 + " | contents: " + e3.getMessage());
        }
    }

    /** 通道1：blobs API */
    private long viaBlobs(String repo, String sha, File dest, GithubApi.Progress prog, long want) throws Exception {
        if (sha == null) throw new java.io.IOException("无 blob sha");
        JSONObject o = new JSONObject(api.call("GET", rp(repo) + "/git/blobs/" + sha, null));
        String b64 = o.optString("content", "").replace("\n", "").replace("\r", "").replace(" ", "");
        long declared = o.optLong("size", -1);
        byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
        long expect = declared > 0 ? declared : want;
        if (expect > 0 && data.length != expect) {
            throw new java.io.IOException("blobs 截断 " + data.length + "/" + expect);
        }
        writeOut(dest, data);
        if (prog != null) prog.on(data.length, data.length);
        return data.length;
    }

    /** 通道2：raw.githubusercontent.com 直链 */
    private long viaRaw(String repo, String path, String ref, File dest, GithubApi.Progress prog, long want) throws Exception {
        String url = "https://raw.githubusercontent.com/" + api.owner + "/" + repo + "/" + GithubApi.enc(ref) + "/" + GithubApi.enc(path);
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestProperty("User-Agent", GithubApi.UA);
        c.setConnectTimeout(20000);
        c.setReadTimeout(600000);
        c.setInstanceFollowRedirects(true);
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new java.io.IOException("raw HTTP " + code);
        long total = c.getContentLength();
        if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
        java.io.InputStream in = c.getInputStream();
        java.io.FileOutputStream fo = new java.io.FileOutputStream(dest);
        byte[] buf = new byte[262144];
        long done = 0;
        int n;
        while ((n = in.read(buf)) > 0) { fo.write(buf, 0, n); done += n; if (prog != null) prog.on(done, total > 0 ? total : done); }
        in.close(); fo.close();
        if (want > 0 && done != want) { dest.delete(); throw new java.io.IOException("raw 截断 " + done + "/" + want); }
        return done;
    }

    /** 通道3：contents API（小文件） */
    private long viaContents(String repo, String path, String ref, File dest, GithubApi.Progress prog, long want) throws Exception {
        String p = rp(repo) + "/contents/" + pEnc(path) + "?ref=" + pEnc(ref);
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(GithubApi.API + p).openConnection();
        c.setRequestProperty("Authorization", "token " + api.token);
        c.setRequestProperty("User-Agent", GithubApi.UA);
        c.setRequestProperty("Accept", "application/vnd.github.raw");
        c.setConnectTimeout(20000);
        c.setReadTimeout(600000);
        c.setInstanceFollowRedirects(true);
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new java.io.IOException("contents HTTP " + code);
        if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
        java.io.InputStream in = c.getInputStream();
        java.io.FileOutputStream fo = new java.io.FileOutputStream(dest);
        byte[] buf = new byte[262144];
        long done = 0;
        int n;
        while ((n = in.read(buf)) > 0) { fo.write(buf, 0, n); done += n; if (prog != null) prog.on(done, done); }
        in.close(); fo.close();
        if (want > 0 && done != want) { dest.delete(); throw new java.io.IOException("contents 截断 " + done + "/" + want); }
        return done;
    }

    private static void writeOut(File dest, byte[] data) throws Exception {
        if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
        java.io.FileOutputStream fo = new java.io.FileOutputStream(dest);
        fo.write(data);
        fo.close();
    }

    /** 在 tree 中查找指定路径的 blob sha */
    public String blobShaOf(String repo, String path, String ref) throws Exception {
        String sha = getRef(repo, ref);
        if (sha == null) {
            JSONObject info = new JSONObject(api.call("GET", rp(repo), null));
            ref = info.optString("default_branch", "main");
            sha = getRef(repo, ref);
        }
        if (sha == null) return null;
        String body = api.call("GET", rp(repo) + "/git/trees/" + sha + "?recursive=1", null);
        JSONArray tree = new JSONObject(body).optJSONArray("tree");
        if (tree == null) return null;
        for (int i = 0; i < tree.length(); i++) {
            JSONObject x = tree.getJSONObject(i);
            if ("blob".equals(x.optString("type")) && path.equals(x.optString("path"))) {
                return x.optString("sha");
            }
        }
        return null;
    }

    /**
     * 递归列出目录下全部文件（一次请求拿全树）。
     * 返回 [{"path":..,"size":..}, ...]，path 为仓库内相对路径。
     */
    public org.json.JSONArray listTree(String repo, String path, String ref) throws Exception {
        String r = (ref == null || ref.isEmpty()) ? "main" : ref;
        String sha = getRef(repo, r);
        if (sha == null) {
            JSONObject info = new JSONObject(api.call("GET", rp(repo), null));
            r = info.optString("default_branch", "main");
            sha = getRef(repo, r);
        }
        if (sha == null) throw new java.io.IOException("找不到分支: " + r);

        String body = api.call("GET", rp(repo) + "/git/trees/" + sha + "?recursive=1", null);
        JSONObject o = new JSONObject(body);
        if (o.optBoolean("truncated")) {
            // 超大树：退化为逐层递归
            return listTreeDeep(repo, path, r, 0);
        }
        JSONArray tree = o.optJSONArray("tree");
        JSONArray out = new JSONArray();
        if (tree == null) return out;
        String prefix = (path == null || path.isEmpty()) ? "" : (path.endsWith("/") ? path : path + "/");
        for (int i = 0; i < tree.length(); i++) {
            JSONObject x = tree.getJSONObject(i);
            if (!"blob".equals(x.optString("type"))) continue;
            String p = x.optString("path");
            if (!prefix.isEmpty()) {
                if (!p.startsWith(prefix)) continue;
            }
            JSONObject y = new JSONObject();
            y.put("path", p);
            y.put("name", p.substring(p.lastIndexOf('/') + 1));
            // 相对路径（用于本地落盘）
            y.put("rel", prefix.isEmpty() ? p : p.substring(prefix.length()));
            y.put("size", x.optLong("size"));
            out.put(y);
        }
        return out;
    }

    /** 退路：逐层递归（应对超大仓库树被截断） */
    private org.json.JSONArray listTreeDeep(String repo, String path, String ref, int depth) throws Exception {
        JSONArray out = new JSONArray();
        if (depth > 12) return out;
        JSONArray items = listDir(repo, path, ref);
        for (int i = 0; i < items.length(); i++) {
            JSONObject x = items.getJSONObject(i);
            String p = x.optString("path");
            if ("dir".equals(x.optString("type"))) {
                JSONArray sub = listTreeDeep(repo, p, ref, depth + 1);
                for (int j = 0; j < sub.length(); j++) out.put(sub.getJSONObject(j));
            } else {
                JSONObject y = new JSONObject();
                y.put("path", p);
                y.put("name", x.optString("name"));
                y.put("size", x.optLong("size"));
                out.put(y);
            }
        }
        return out;
    }

    /**
     * 拉取当前账号可用的仓库列表（含自己、协作、组织）。
     * 按最近更新排序，只保留有推送权限的。
     */
    public org.json.JSONArray listRepos() throws Exception {
        org.json.JSONArray out = new org.json.JSONArray();
        int page = 1;
        while (page <= 5) {
            String p = "/user/repos?per_page=100&page=" + page
                     + "&sort=updated&affiliation=owner,collaborator,organization_member";
            String body = api.call("GET", p, null);
            org.json.JSONArray arr = new org.json.JSONArray(body);
            if (arr.length() == 0) break;
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject r = arr.getJSONObject(i);
                org.json.JSONObject perms = r.optJSONObject("permissions");
                boolean canPush = perms != null && perms.optBoolean("push", false);
                if (!canPush) continue;   // 不能推的不列
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("name", r.optString("name"));
                o.put("full", r.optString("full_name"));
                o.put("private", r.optBoolean("private", false));
                o.put("size", r.optLong("size", 0) * 1024L);
                o.put("branch", r.optString("default_branch", "main"));
                o.put("desc", r.optString("description", ""));
                o.put("updated", r.optString("updated_at", "").replace("T", " ").substring(0, Math.min(16, r.optString("updated_at", "").length())));
                out.put(o);
            }
            if (arr.length() < 100) break;
            page++;
        }
        return out;
    }

    /** 当前账号信息 */
    public org.json.JSONObject whoAmI() throws Exception {
        return new org.json.JSONObject(api.call("GET", "/user", null));
    }

    /**
     * 稳健下载：分段拉取 + 校验 + 断点保留。
     *
     * 背景：实测本机到 api.github.com 传大文件常出现 IncompleteRead，
     * 而 blobs API 不支持 Range 头。因此策略是：
     *   1) 先尝试整体 raw 流式下载，边下边写
     *   2) 中途断了不丢弃已下部分，保留 .part 文件
     *   3) 重试时从头再来（因不支持 Range），但最多 N 次
     *   4) 下完用 git blob sha1 校验，不符则重试
     *   5) 全部失败则保留 .part 供人工处理，绝不假装成功
     */
    /** 状态文本回调，用于向界面报告重试等过程 */
    public interface Note { void say(String text); }

    public long downloadStable(String repo, String path, String ref, File dest,
                               GithubApi.Progress prog, int maxTry) throws Exception {
        return downloadStable(repo, path, ref, dest, prog, maxTry, null);
    }

    public long downloadStable(String repo, String path, String ref, File dest,
                               GithubApi.Progress prog, int maxTry, Note note) throws Exception {
        String r = (ref == null || ref.isEmpty()) ? "main" : ref;
        String sha = blobShaOf(repo, path, r);
        if (sha == null) throw new java.io.IOException("仓库里找不到: " + path);
        long want = blobSizeOf(repo, path, r);
        String url = GithubApi.API + rp(repo) + "/git/blobs/" + sha;
        File part = new File(dest.getAbsolutePath() + ".part");
        if (dest.getParentFile() != null) dest.getParentFile().mkdirs();

        String lastErr = null;
        for (int attempt = 1; attempt <= maxTry; attempt++) {
            try {
                long n = streamTo(url, part, prog);
                // 尺寸校验
                if (want > 0 && n != want) {
                    throw new java.io.IOException("字节数不符 " + n + "/" + want);
                }
                // git blob sha1 校验（内容级）
                String got = gitBlobSha1(part);
                if (!got.equalsIgnoreCase(sha)) {
                    throw new java.io.IOException("内容校验失败");
                }
                // 通过：改名落地
                if (dest.exists()) dest.delete();
                if (!part.renameTo(dest)) {
                    // 改名失败则拷贝
                    java.io.FileInputStream in = new java.io.FileInputStream(part);
                    java.io.FileOutputStream out = new java.io.FileOutputStream(dest);
                    byte[] buf = new byte[262144];
                    int k;
                    while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
                    in.close(); out.close();
                    part.delete();
                }
                return n;
            } catch (Exception e) {
                lastErr = shortErr(e);
                long got = part.exists() ? part.length() : 0;
                if (attempt < maxTry) {
                    if (note != null) {
                        note.say("第 " + attempt + " 次中断（已收 " + human(got)
                               + "），" + (attempt < maxTry ? "重试中…" : ""));
                    }
                    // 退避后重试
                    try { Thread.sleep(Math.min(2000L * attempt, 10000L)); } catch (InterruptedException ie) {}
                } else {
                    if (note != null) note.say("重试 " + maxTry + " 次均失败");
                }
            }
        }
        throw new java.io.IOException("重试 " + maxTry + " 次仍失败（保留 .part）: " + lastErr);
    }

    /** 友好错误名 */
    static String shortErr(Exception e) {
        String n = e.getClass().getSimpleName();
        if (n.contains("IncompleteRead") || n.contains("EOFException")) return "连接被截断";
        if (n.contains("SocketTimeout") || n.contains("Timeout")) return "超时";
        if (n.contains("UnknownHost") || n.contains("Connect")) return "连不上";
        String m = e.getMessage();
        return m == null ? n : m;
    }

    /** 字节数友好显示 */
    static String human(long n) {
        if (n < 1024) return n + " B";
        if (n < 1048576) return String.format("%.1f KB", n / 1024.0);
        if (n < 1073741824L) return String.format("%.1f MB", n / 1048576.0);
        return String.format("%.2f GB", n / 1073741824.0);
    }

    /** raw 模式流式写入文件 */
    private long streamTo(String url, File out, GithubApi.Progress prog) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestProperty("Authorization", "token " + api.token);
        c.setRequestProperty("User-Agent", GithubApi.UA);
        c.setRequestProperty("Accept", "application/vnd.github.raw");
        c.setConnectTimeout(20000);
        c.setReadTimeout(600000);
        c.setInstanceFollowRedirects(true);
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new java.io.IOException("HTTP " + code);
        long total = c.getContentLength();
        java.io.InputStream in = c.getInputStream();
        java.io.FileOutputStream fo = new java.io.FileOutputStream(out);
        byte[] buf = new byte[262144];
        long done = 0;
        int n;
        while ((n = in.read(buf)) > 0) {
            fo.write(buf, 0, n);
            done += n;
            if (prog != null) prog.on(done, total > 0 ? total : done);
        }
        in.close();
        fo.close();
        return done;
    }

    /** 计算 git blob sha1：sha1("blob " + len + "\0" + content) */
    static String gitBlobSha1(File f) throws Exception {
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
        long len = f.length();
        md.update(("blob " + len + "\u0000").getBytes("UTF-8"));
        java.io.FileInputStream in = new java.io.FileInputStream(f);
        byte[] buf = new byte[262144];
        int n;
        while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        in.close();
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    /** 在 tree 中找文件大小 */
    public long blobSizeOf(String repo, String path, String ref) throws Exception {
        String sha = getRef(repo, ref);
        if (sha == null) {
            JSONObject info = new JSONObject(api.call("GET", rp(repo), null));
            ref = info.optString("default_branch", "main");
            sha = getRef(repo, ref);
        }
        if (sha == null) return -1;
        JSONArray tree = new JSONObject(api.call("GET", rp(repo) + "/git/trees/" + sha + "?recursive=1", null)).optJSONArray("tree");
        if (tree == null) return -1;
        for (int i = 0; i < tree.length(); i++) {
            JSONObject x = tree.getJSONObject(i);
            if ("blob".equals(x.optString("type")) && path.equals(x.optString("path"))) {
                return x.optLong("size", -1);
            }
        }
        return -1;
    }
}
