package com.qingxuan.wenpush;

import org.json.*;
import java.io.*;
import java.net.*;

/**
 * GitHub Device Flow 登录。
 * 流程：申请设备码 → 用户去网页输码 → 轮询拿令牌。
 * 青玄
 */
public class OAuth {

    public static final String CODE_URL = "https://github.com/login/device/code";
    public static final String TOKEN_URL = "https://github.com/login/oauth/access_token";
    public static final String VERIFY_URL = "https://github.com/login/device";
    public static final String GRANT = "urn:ietf:params:oauth:grant-type:device_code";

    /** 默认 client_id（GitHub CLI 的公开值，可直接用；建议自己建一个） */
    public static final String DEFAULT_CLIENT = "178c6fc778ccc68e1d6a";

    public static class Device {
        public String deviceCode, userCode, verifyUri;
        public int interval = 5, expiresIn = 900;
    }

    private static String post(String url, String form) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(20000);
        c.setReadTimeout(30000);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        c.setRequestProperty("User-Agent", GithubApi.UA);
        byte[] b = form.getBytes("UTF-8");
        c.setFixedLengthStreamingMode(b.length);
        OutputStream os = c.getOutputStream();
        os.write(b);
        os.flush();
        os.close();
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        String body = is == null ? "" : GithubApi.slurp(is);
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + body);
        return body;
    }

    /** 第一步：拿设备码 */
    public static Device requestCode(String clientId, String scope) throws Exception {
        String cid = (clientId == null || clientId.isEmpty()) ? DEFAULT_CLIENT : clientId;
        String body = post(CODE_URL, "client_id=" + enc(cid) + "&scope=" + enc(scope == null ? "repo" : scope));
        JSONObject o = new JSONObject(body);
        Device d = new Device();
        d.deviceCode = o.getString("device_code");
        d.userCode = o.getString("user_code");
        d.verifyUri = o.optString("verification_uri", VERIFY_URL);
        d.interval = o.optInt("interval", 5);
        d.expiresIn = o.optInt("expires_in", 900);
        return d;
    }

    /**
     * 第二步：轮询。返回 null 表示还在等；返回字符串表示拿到令牌或出错。
     * 结果用简单前缀区分：ok:xxx / err:xxx / wait
     */
    public static String pollOnce(String clientId, String deviceCode) throws Exception {
        String cid = (clientId == null || clientId.isEmpty()) ? DEFAULT_CLIENT : clientId;
        String body = post(TOKEN_URL,
            "client_id=" + enc(cid) + "&device_code=" + enc(deviceCode) + "&grant_type=" + enc(GRANT));
        JSONObject o = new JSONObject(body);
        if (o.has("access_token")) return "ok:" + o.getString("access_token");
        String err = o.optString("error", "");
        if ("authorization_pending".equals(err)) return "wait";
        if ("slow_down".equals(err)) return "slow";
        if ("expired_token".equals(err)) return "err:验证码已过期，请重新获取";
        if ("access_denied".equals(err)) return "err:你取消了授权";
        if ("incorrect_client_credentials".equals(err)) return "err:client_id 不对";
        return "err:" + o.optString("error_description", err);
    }

    private static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }
}
