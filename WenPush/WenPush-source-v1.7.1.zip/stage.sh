#!/bin/bash
# 部署脚本：把当前版本复制到手机目录，并只清理真正过期的文件
# 教训：不能写死要删的版本号，否则可能误删刚复制的新版
set -u
cd "$(dirname "$0")"

VER=$(grep -oP 'android:versionName="\K[^"]+' AndroidManifest.xml)
APK=build/WenPush-v${VER}.apk
DIR=/sdcard/Download/WenPush

echo "当前版本: v${VER}"
[ -f "$APK" ] || { echo "找不到 $APK，先构建"; exit 1; }

mkdir -p $DIR

# 1) 先复制新文件
cp "$APK" $DIR/
cp assets/index.html $DIR/ui-v${VER}.html
python3 - << PYEOF
import zipfile, os
z = zipfile.ZipFile('$DIR/WenPush-source-v${VER}.zip', 'w', zipfile.ZIP_DEFLATED)
for root, dirs, files in os.walk('.'):
    if 'build' in root.split(os.sep): continue
    for f in files:
        if f.endswith(('.apk','.log')): continue
        p = os.path.join(root, f)
        z.write(p, os.path.relpath(p, '.'))
z.close()
print('  源码包已打包')
PYEOF

# 2) 删掉除当前版本外的所有 WenPush 产物（保留当前版本，绝不误删）
KEEP="v${VER}"
shopt -s nullglob
for f in $DIR/WenPush-*.apk $DIR/WenPush-source-*.zip $DIR/ui-v*.html; do
    case "$f" in
        *"$KEEP"*) : ;;                     # 当前版本，留
        *) echo "  清理过期: $(basename "$f")"; rm -f "$f" ;;
    esac
done

# 3) 报告结果
echo ""
echo "部署完成，目录内容："
ls -la $DIR
echo ""
echo "APK md5: $(md5sum $DIR/WenPush-v${VER}.apk | cut -d' ' -f1)"
