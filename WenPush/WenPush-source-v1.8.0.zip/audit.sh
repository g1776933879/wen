#!/bin/bash
# WenPush 交付前自动审计 —— 青玄
set -u
cd "$(dirname "$0")"
APK=$(ls -t build/WenPush-v*.apk 2>/dev/null | head -1)
PASS=0; FAIL=0

ok(){ echo "  ✓ $1"; PASS=$((PASS+1)); }
ng(){ echo "  ✗ $1"; FAIL=$((FAIL+1)); }

# 抽取 APK 里的资源
TMP=$(mktemp -d)
python3 - << PYEOF
import zipfile
z = zipfile.ZipFile('$APK')
z.extract('assets/index.html', '$TMP')
open('$TMP/classes.dex','wb').write(z.read('classes.dex'))
PYEOF

HTML=$TMP/assets/index.html
JS=$TMP/ui.js
python3 -c "
import re
h=open('$HTML',encoding='utf-8').read()
js=re.search(r'<script>(.*?)</script>',h,re.S)
open('$JS','w',encoding='utf-8').write(js.group(1) if js else '')
"

echo "=== 1) JS 语法 ==="
if node --check "$JS" 2>/dev/null; then ok "语法正确"; else ng "语法错误"; node --check "$JS" 2>&1 | head -3 | sed 's/^/      /'; fi

echo "=== 2) 接口对账 ==="
python3 - << PYEOF
import re
h = open('$HTML', encoding='utf-8').read()
js = re.search(r'<script>(.*?)</script>', h, re.S).group(1)
ma = open('src/com/qingxuan/wenpush/MainActivity.java', encoding='utf-8').read()
api = ma[ma.index('class Api'):]
jm = set(re.findall(r'public\s+(?:void|String)\s+(\w+)\s*\(', api))
jc = set(re.findall(r'WenPush\.(\w+)\s*\(', js))
miss = sorted(jc - jm)
print('  ' + ('✓ 接口全部对得上' if not miss else '✗ 悬空调用: ' + str(miss)))
import sys
sys.exit(0 if not miss else 1)
PYEOF

echo "=== 3) evaluateJavascript 转义 ==="
python3 - << PYEOF
import re, glob
bad = []
for f in glob.glob('src/com/qingxuan/wenpush/*.java'):
    for i, l in enumerate(open(f, encoding='utf-8').read().split('\n'), 1):
        if 'evaluateJavascript' not in l: continue
        seg = l.split('evaluateJavascript(')[1]
        if 'JSONObject.quote' not in seg and '+' in seg:
            bad.append('%s:%d' % (f.split('/')[-1], i))
print('  ' + ('✓ 全部已转义' if not bad else '✗ 未转义: ' + str(bad)))
PYEOF

echo "=== 4) HTML 函数引用 ==="
python3 - << PYEOF
import re
h = open('$HTML', encoding='utf-8').read()
js = re.search(r'<script>(.*?)</script>', h, re.S).group(1)
html = h[:h.index('<script>')]
d = set(re.findall(r'function\s+(\w+)', js))
c = set(re.findall(r'on\w+="(\w+)\(', html))
miss = sorted(c - d)
print('  ' + ('✓ 无悬空引用' if not miss else '✗ 未定义: ' + str(miss)))
PYEOF

echo "=== 5) id 引用 ==="
python3 - << PYEOF
import re
h = open('$HTML', encoding='utf-8').read()
js = re.search(r'<script>(.*?)</script>', h, re.S).group(1)
html = h[:h.index('<script>')]
ids = set(re.findall(r'id="([\w-]+)"', html))
ref = set(re.findall(r"\$\('#([\w-]+)'\)", js))
miss = sorted(ref - ids)
print('  ' + ('✓ 无悬空 id' if not miss else '✗ 缺 id: ' + str(miss)))
PYEOF

echo "=== 6) 签名 ==="
if apksigner verify "$APK" >/dev/null 2>&1; then ok "签名有效"; else ng "签名无效"; fi

echo "=== 7) dex 关键方法 ==="
python3 - << PYEOF
d = open('$TMP/classes.dex','rb').read()
need = [b'loginStart', b'pollOnce', b'saveTheme', b'listRepos', b'downloadStable', b'safeFail']
miss = [k.decode() for k in need if k not in d]
print('  ' + ('✓ 关键方法齐全' if not miss else '✗ 缺失: ' + str(miss)))
PYEOF

rm -rf $TMP
echo ""
echo "========== 结果: $PASS 通过 / $FAIL 失败 =========="
[ $FAIL -eq 0 ] && echo "✅ 可以交付" || echo "❌ 存在问题，不要交付"
